 "use client";

import { useState } from "react";
import { createSupabaseBrowserClient } from "../../lib/supabase/client";

export default function SignupPage() {
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [name,setName]=useState("");
  const [message,setMessage]=useState("");
  const [loading,setLoading]=useState(false);

  async function submit(e){
    e.preventDefault(); setLoading(true); setMessage("");
    try{
      const supabase=createSupabaseBrowserClient();
      const {error}=await supabase.auth.signUp({
        email,password,
        options:{data:{full_name:name}}
      });
      if(error) throw error;
      setMessage("Account created. Check your email if email confirmation is enabled.");
    }catch(err){setMessage(err.message)}
    finally{setLoading(false)}
  }

  return <div className="container">
    <h1>Create account</h1>
    <form className="form" onSubmit={submit}>
      <input className="input" placeholder="Full name" value={name} onChange={e=>setName(e.target.value)} />
      <input className="input" type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required/>
      <input className="input" type="password" minLength="6" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} required/>
      <button className="btn" disabled={loading}>{loading?"Creating…":"Create account"}</button>
      {message && <div className="success">{message}</div>}
    </form>
  </div>;
}
