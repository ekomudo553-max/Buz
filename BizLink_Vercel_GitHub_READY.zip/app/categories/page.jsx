import { createSupabaseServerClient } from "../../lib/supabase/server";

export const dynamic="force-dynamic";

export default async function Categories(){
  let categories=[], error=null;
  try{
    const supabase=await createSupabaseServerClient();
    const result=await supabase.from("categories").select("id,name,slug,description").order("name");
    categories=result.data||[]; error=result.error?.message||null;
  }catch(e){error=e.message}
  return <div className="container"><h1>Categories</h1>{error&&<div className="notice">{error}</div>}
    <div className="grid">{categories.map(c=><div className="card" key={c.id}><h3>{c.name}</h3><p>{c.description}</p></div>)}</div>
  </div>
}
