import {createSupabaseServerClient} from "../../../../lib/supabase/server";

export async function POST(request){
  try{
    const secret=process.env.PAYSTACK_SECRET_KEY;
    if(!secret)return Response.json({error:"PAYSTACK_SECRET_KEY is not configured yet."},{status:503});
    const supabase=await createSupabaseServerClient();
    const {data:{user}}=await supabase.auth.getUser();
    if(!user)return Response.json({error:"Authentication required."},{status:401});

    const body=await request.json().catch(()=>({}));
    const plan=body.plan||"featured_monthly";
    const amount=500000; // ₦5,000 example — change to your production price.
    const callback=`${process.env.NEXT_PUBLIC_APP_URL||request.nextUrl.origin}/pricing/checkout`;

    const response=await fetch("https://api.paystack.co/transaction/initialize",{
      method:"POST",
      headers:{"Authorization":`Bearer ${secret}`,"Content-Type":"application/json"},
      body:JSON.stringify({email:user.email,amount,callback_url:callback,metadata:{user_id:user.id,plan}})
    });
    const data=await response.json();
    if(!response.ok||!data.status)return Response.json({error:data.message||"Paystack initialization failed."},{status:400});
    return Response.json({authorization_url:data.data.authorization_url,reference:data.data.reference});
  }catch(e){return Response.json({error:e.message},{status:500});}
}
