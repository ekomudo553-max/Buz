import {createSupabaseServerClient} from "../../../lib/supabase/server";

export async function GET(){
  try{
    const supabase=await createSupabaseServerClient();
    const {data,error}=await supabase.from("categories").select("id,name,slug,description").order("name");
    if(error)return Response.json({error:error.message},{status:500});
    return Response.json({categories:data||[]});
  }catch(e){return Response.json({error:e.message},{status:500});}
}
