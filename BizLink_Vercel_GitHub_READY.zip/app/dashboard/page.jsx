import Link from "next/link";
import {createSupabaseServerClient} from "../../lib/supabase/server";

export const dynamic="force-dynamic";

export default async function Dashboard(){
  let user=null, businesses=[], profile=null, error=null;
  try{
    const supabase=await createSupabaseServerClient();
    const auth=await supabase.auth.getUser();
    user=auth.data.user;
    if(user){
      const p=await supabase.from("profiles").select("*").eq("id",user.id).single();
      profile=p.data;
      const b=await supabase.from("businesses").select("id,name,status,is_featured,featured_until").eq("owner_id",user.id).order("created_at",{ascending:false});
      businesses=b.data||[];
    }
  }catch(e){error=e.message}

  if(!user) return <div className="container"><h1>Dashboard</h1><p>Please sign in.</p><Link className="btn" href="/login">Sign in</Link></div>;

  return <div className="container">
    <h1>Dashboard</h1><p className="muted">{user.email}</p>
    {error&&<div className="notice">{error}</div>}
    <div className="row"><Link className="btn" href="/businesses/new">Add business</Link>{profile?.role==="admin"&&<Link className="btn secondary" href="/admin">Admin dashboard</Link>}</div>
    <h2>Your businesses</h2>
    <div className="grid">{businesses.map(b=><div className="card" key={b.id}><h3>{b.name}</h3><p>Status: {b.status}</p>{b.is_featured&&<span className="pill">Featured</span>}</div>)}</div>
  </div>
}
