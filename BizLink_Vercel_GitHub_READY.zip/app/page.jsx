import Link from "next/link";

export default function Home() {
  return (
    <>
      <section className="hero">
        <div className="container">
          <p className="pill">Local business discovery</p>
          <h1>Find trusted businesses around you.</h1>
          <p className="muted">BizLink helps customers discover businesses and helps owners get found online.</p>
          <div className="row">
            <Link className="btn" href="/businesses">Explore businesses</Link>
            <Link className="btn secondary" href="/businesses/new">List your business</Link>
          </div>
        </div>
      </section>
      <section className="container">
        <div className="grid">
          <div className="card"><h3>Discover</h3><p>Search local businesses by category.</p></div>
          <div className="card"><h3>Build trust</h3><p>Read reviews and view business profiles.</p></div>
          <div className="card"><h3>Grow</h3><p>Owners can promote listings and receive enquiries.</p></div>
        </div>
      </section>
    </>
  );
}
